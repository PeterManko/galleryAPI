<?php

namespace App\Http\Controllers;

use App\images;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class deleteImages extends Controller
{
    public function deleteImage( $gallery, $path){
        //saving image path
        $imagePath = $gallery . '/' . $path;
        //checking if image exists
        if(File::exists($imagePath)) {
            //deleting image form db
            images::where('path' , $path)->delete();
            //deleteing image file
            File::delete($imagePath);
            //returning status 200
            return response("Obrázok bol úspešne vymazaný",200);
        }
        //image doesn't exist, returning 404
        else
            return response('Zvolená galéria/obrázok neexistuje', 404);
    }
}
