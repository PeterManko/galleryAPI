<?php

namespace App\Http\Controllers;

use App\Gals;
use App\images;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Intervention\Image\Facades\Image;

class uploadImage extends Controller
{
    public function uploadImage(Request $request, $galeryName){
        //checking if is uploaded file valid and has valid name
        if ($request->filename != null and $request->name != null){
            //checking if entered gallery exists
            if (Gals::where('name', $galeryName)->exists()){
                //gettind galllery's id
                $gals_id=Gals::all()->where('name', $galeryName)->first();
                //setting file name and full path
                $filename = $request->filename->getClientOriginalName();
                $fullpath = $galeryName.'/'.$filename;
                //checking if image already exist, if yes, updating his name
                if(images::where('fullPath', $fullpath)->exists()){
                    images::where('path', $filename)->first()
                    ->update(['name' => $request->name]);
                }
                //if not creating him
                else
                    images::create(['name'=> $request->name, 'path' => $filename, 'fullPath'=> $fullpath, 'gals_id' => $gals_id->id]);
                //updating/inserting image to gallery directory
                Image::make($request->filename)
                    ->orientate()
                       ->save(public_path($fullpath));
                //returning json with image details and code 201
                return response()->json([
                        "uploaded" => [
                            images::select('name', 'path', 'fullPath', 'created_at', 'updated_at')->first(),
                        ]
                    ],201
                );

            }
            //returning code 404
            else return $this->return404();
        }
        //returning conde 400
        else return $this->return400();
    }

    public function return400   ()
    {
        return response('Chybný request - nenašiel sa súbor pre upload.', 409)
            ->header('Content-Type', 'text/plain');
    }

    public function return404()
    {
        return response('Galéria pre upload sa nenašla', 400)
            ->header('Content-Type', 'text/plain');
    }
}
