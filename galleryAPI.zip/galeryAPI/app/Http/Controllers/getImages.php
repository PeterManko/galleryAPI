<?php

namespace App\Http\Controllers;

use App\Gals;
use App\images;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

class getImages extends Controller
{
    public function getImages(Request $request, $galleryName){
        //checking if gallery exist
        if (Gals::where('name', $galleryName)->exists()){
            //getting information about selected gallery
            $gals_id = Gals::select('id')->where('name', $galleryName)->first();
            //getting info about all images in gallery
            $images = images::select('name', 'path', 'fullPath', 'created_at', 'updated_at')->where('gals_id', $gals_id->id)->get();
            //returning json with all informations
            return response()->json([
                "gallery details" =>[
                    'name' => $galleryName,
                    'path' => '/'.$galleryName,
                    'id' => $gals_id->id,
                ],
                'images' =>[
                    $images
                ]
            ]);
        }
        //gallery doesn't exist
        else
            return response('Zvolená galéria neexistuje', 404);


    }
    //function for preview 1 image in custom size
    public function getImage($w, $h, $gallery, $path){
        //checking if width or hight isn't lower than 1, if yes setting to auto
        if ($w<1)
            $w = "auto";
        if ($h<1)
            $h = "auto";
        //returning image in custom size
        return response('<img src="' . public_path($gallery) . '/' . $path . '" alt="Preview" style=" width:' . $w .' ;height:' . $h .'">');
    }
}
