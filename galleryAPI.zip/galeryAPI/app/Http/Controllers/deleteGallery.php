<?php

namespace App\Http\Controllers;

use App\Gals;
use App\images;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class deleteGallery extends Controller
{
    public function deleteGallery($name){
        //chcecking if gallery exists
        if (Gals::where('name', $name)->exists()){
            //getting her id
            $galId = Gals::where('name', $name)->first()->id;
            //deleting all images under that gallery
            images::where('gals_id', $galId)->delete();
            //deleting  gallery
            Gals::where('name', $name)->delete();
            //deleting gallery's directory
            File::deleteDirectory(public_path($name));
            //response with code 200
            return response("Galéria bola úspešne vymazaná",200);
        }
        //gallery doesn't exist, returning 404
        else
            return response('Zvolená galéria/obrázok neexistuje', 404);

    }
}
