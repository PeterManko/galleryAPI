<?php

namespace App\Http\Controllers;

use App\Gals;
use App\images;
use Illuminate\Support\Facades\DB;

class getGals extends Controller
{
    public function getGals()
    {
        //getting info about all galleries and their images
        $all=Gals::with('images')->get();
        //returning json with info data
        return response()->json([
            "galeries" => [
                $all
            ]
        ]);
    }
}
