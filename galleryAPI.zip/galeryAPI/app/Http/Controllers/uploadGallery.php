<?php

namespace App\Http\Controllers;

use App\Gals;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

class uploadGallery extends uploadImage
{
    public function uploadGallery(Request $request)
    {
        //checking if is gallery name valid
        if ($request->name != null and !Str::contains($request->name, '/')) {
            //checking if gallery exists
            if (!Gals::where('name', $request->name)->exists()) {
                //creating gallery in database
                Gals::create(['name' => $request->name, 'path' => '/'.$request->name]);
                //creating gallery's directory
                File::makeDirectory($request->name);
                //returning status 201 with gallery details
                return response()->json([
                    "name" => "$request->name",
                    "path" => "/$request->name",
                ],201
                );

            }
            //gallery exists
            else {
                return $this->return409();
            }

        }
        //gallery name is not valid
        else {
            return $this->return400();

        }
    }
    //returning status 409
    public function return409()
    {
        return response('Chybne zadaný request - galéria už existuje.', 409)
            ->header('Content-Type', 'text/plain');
    }
    //returning status 400
    public function return400()
    {
        return response('Chybne zadaný request - nevhodný obsah podľa schémy.', 400)
            ->header('Content-Type', 'text/plain');
    }


}
