<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gals extends Model
{
    //using table gals
    protected $table='gals';
    //enabling auto timestamps
    public $timestamps = true;
    //enabling to fill columns name and path
    protected $fillable = ['name', 'path'];
    //creating relations oneToMany
    public function images(){
        return $this->hasMany(images::class);
    }}
