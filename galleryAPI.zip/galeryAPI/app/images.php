<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class images extends Model
{
    //using table images
    protected $table='images';
    //enable useing auto timestamps
    public $timestamps = true;
    //enabling to fill columns name, path, fullPath and gals_id, witch is foreign kei
    protected $fillable = ['name', 'path', 'fullPath', 'gals_id'];

    //creating relations oneToMany inverted
    public function Gals(){
    return $this->belongsTo(Gals::class);
}
}
