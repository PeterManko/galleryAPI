<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
//defining all post requests
Route::post("/gallery", "uploadGallery@uploadGallery");
Route::post("/gallery/{galleryName}", "uploadImage@uploadImage" );
//defining all get requests
Route::get("/gallery", "getGals@getGals");
Route::get('/gallery/{name}', 'getImages@getImages');
Route::get('/gallery/{w}x{h}/{gallery}/{path}', 'getImages@getImage');
//defining all delete requests
Route::delete('/gallery/{gallery}/{path}', 'deleteImages@deleteImage');
Route::delete('/gallery/{gallery}', 'deleteGallery@deleteGallery');


